#ifndef __HEAP_H__
#define __HEAP_H__
typedef struct _minHeap
{
    short * d;
    int ct;
    int cap;
    int* el;

} minHeap;


#endif
